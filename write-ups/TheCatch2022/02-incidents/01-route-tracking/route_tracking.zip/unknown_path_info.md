# Delivery path info

* Start depot: Area_52
* End depot: Area_52
* Total length: 163912 m / 537769.029 feets / 179256.34300000002 yards / 88.50539958920086292 nautical miles
* Path identifier: <error 27: broken recorder>
* Driver: Eve Evans
* AES Van number: 1572
* Comment: send immediately for repair
