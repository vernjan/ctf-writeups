# Automated folder backup

* Paths
	* `C:\users\brendasmith\Download`
* Password: `password`
* Files control hashes:
	* `download_backup.rar - e50dff6ccd458f5a50ed47522d519277`
* Backup transaction ID: `42776559928`
